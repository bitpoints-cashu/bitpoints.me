var s="/assets/bitpoints-logo.25549e48.png",o="/assets/trails-logo.1372c88a.png";export{s as b,o as t};
