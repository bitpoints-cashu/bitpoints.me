import{v as m}from"./index.09689626.js";import{i as o}from"./vue-qrcode.esm.2e9034a1.js";var e=m(async({app:a})=>{a.component(o.name,o)});export{e as default};
