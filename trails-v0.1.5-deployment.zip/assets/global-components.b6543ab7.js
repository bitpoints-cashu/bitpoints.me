import{v as m}from"./index.77df0667.js";import{i as o}from"./vue-qrcode.esm.08815310.js";var e=m(async({app:a})=>{a.component(o.name,o)});export{e as default};
