import{m as a,b8 as r}from"./index.77df0667.js";function u(){return a(r)}export{u};
