import{m as a,b8 as r}from"./index.09689626.js";function u(){return a(r)}export{u};
