var a="/assets/trails-logo.1372c88a.png";export{a as t};
