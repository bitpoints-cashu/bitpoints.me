import{v as m}from"./index.101bbc77.js";import{i as o}from"./vue-qrcode.esm.108091c0.js";var e=m(async({app:a})=>{a.component(o.name,o)});export{e as default};
