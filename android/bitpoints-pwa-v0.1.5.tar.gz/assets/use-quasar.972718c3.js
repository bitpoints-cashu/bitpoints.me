import{m as a,b8 as r}from"./index.101bbc77.js";function u(){return a(r)}export{u};
