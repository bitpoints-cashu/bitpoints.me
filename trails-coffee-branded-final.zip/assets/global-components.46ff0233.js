import{v as m}from"./index.acdb93e1.js";import{i as o}from"./vue-qrcode.esm.b1a3ef99.js";var e=m(async({app:a})=>{a.component(o.name,o)});export{e as default};
