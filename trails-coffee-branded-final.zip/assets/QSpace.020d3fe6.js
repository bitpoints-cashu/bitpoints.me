import{x as e,j as s}from"./index.acdb93e1.js";var c=e({name:"QSpace",setup(){const a=s("div",{class:"q-space"});return()=>a}});export{c as Q};
